the main two input field in teh first menu are for the x and y input numbers for the functions

if -1 is inputted then x is used however a constant will be used if another number is specified
